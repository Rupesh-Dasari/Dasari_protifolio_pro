import type { Metadata, Viewport } from 'next'
import { Inter, Sora } from 'next/font/google'
import './globals.css'
import { ThemeProvider } from '@/components/theme-provider'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
const sora = Sora({ subsets: ['latin'], variable: '--font-sora' })

export const metadata: Metadata = {
  title: 'Dasari Rupesh | Python Developer & AI Automation Engineer',
  description:
    'Python Developer and AI & Automation Engineer in Bengaluru. Backend services, REST APIs, AI agents and document automation with Django, FastAPI, LangGraph and MySQL.',
  keywords: ['Python developer', 'AI automation engineer', 'Django', 'FastAPI', 'LangGraph', 'Bengaluru'],
  authors: [{ name: 'Dasari Rupesh' }],
  openGraph: {
    title: 'Dasari Rupesh | Python Developer & AI Automation Engineer',
    description: 'Backend services, REST APIs, AI agents and document automation.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#f4f6fc' },
    { media: '(prefers-color-scheme: dark)', color: '#05070f' },
  ],
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} ${sora.variable} font-sans antialiased`}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
