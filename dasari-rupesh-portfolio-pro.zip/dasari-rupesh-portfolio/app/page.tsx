import Navigation from '@/components/navigation'
import SceneLayer from '@/components/scene-layer'
import Intro from '@/components/intro'
import HeroSection from '@/components/sections/hero-section'
import AboutSection from '@/components/sections/about-section'
import JourneySection from '@/components/sections/journey-section'
import ProjectsSection from '@/components/sections/projects-section'
import SkillsSection from '@/components/sections/skills-section'
import ContactSection from '@/components/sections/contact-section'
import Footer from '@/components/footer'

export default function Home() {
  return (
    <>
      <Intro />
      <SceneLayer />
      <Navigation />
      <div className="relative z-10">
        <main className="overflow-x-clip">
          <HeroSection />
          <AboutSection />
          <JourneySection />
          <ProjectsSection />
          <SkillsSection />
          <ContactSection />
        </main>
        <Footer />
      </div>
    </>
  )
}
