'use client'
import { useEffect, useState } from 'react'
import { isWebGLAvailable } from '@/lib/utils'

/** null until checked on the client, then true / false. */
export function useWebGL() {
  const [ok, setOk] = useState<boolean | null>(null)
  useEffect(() => setOk(isWebGLAvailable()), [])
  return ok
}
