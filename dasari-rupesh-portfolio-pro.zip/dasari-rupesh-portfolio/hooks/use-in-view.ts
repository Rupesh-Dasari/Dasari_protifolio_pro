'use client'
import { useEffect, useRef, useState } from 'react'

/** True while the element is on screen. Used to pause 3D rendering off-screen. */
export function useInView<T extends HTMLElement>(margin = '120px') {
  const ref = useRef<T>(null)
  const [inView, setInView] = useState(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    if (!('IntersectionObserver' in window)) {
      setInView(true)
      return
    }
    const io = new IntersectionObserver(([entry]) => setInView(entry.isIntersecting), {
      rootMargin: margin,
    })
    io.observe(el)
    return () => io.disconnect()
  }, [margin])

  return [ref, inView] as const
}
