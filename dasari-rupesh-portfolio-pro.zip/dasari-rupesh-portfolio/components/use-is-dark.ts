'use client'

import { useEffect, useState } from 'react'
import { useTheme } from 'next-themes'

/** Resolved dark mode, safe for the first render (assumes dark until mounted). */
export function useIsDark() {
  const { resolvedTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])
  return mounted ? resolvedTheme !== 'light' : true
}
