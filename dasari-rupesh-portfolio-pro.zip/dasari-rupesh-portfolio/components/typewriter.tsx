'use client'

import { useEffect, useState } from 'react'
import { useReducedMotion } from 'motion/react'

export default function Typewriter({ phrases }: { phrases: string[] }) {
  const reduced = useReducedMotion()
  const [index, setIndex] = useState(0)
  const [text, setText] = useState(phrases[0])
  const [deleting, setDeleting] = useState(false)

  useEffect(() => {
    if (reduced) return
    const full = phrases[index]
    let delay = deleting ? 28 : 55
    if (!deleting && text === full) delay = 1700
    if (deleting && text === '') delay = 250

    const id = setTimeout(() => {
      if (!deleting && text === full) setDeleting(true)
      else if (deleting && text === '') {
        setDeleting(false)
        setIndex((i) => (i + 1) % phrases.length)
      } else {
        setText(deleting ? full.slice(0, text.length - 1) : full.slice(0, text.length + 1))
      }
    }, delay)
    return () => clearTimeout(id)
  }, [text, deleting, index, phrases, reduced])

  return (
    <span>
      <span className="sr-only">{phrases.join(', ')}</span>
      <span aria-hidden="true" className="liquid-gradient font-semibold">
        {reduced ? phrases[0] : text}
      </span>
      <span aria-hidden="true" className="caret ml-0.5 inline-block h-[1em] w-[2px] translate-y-[0.15em] bg-g2" />
    </span>
  )
}
