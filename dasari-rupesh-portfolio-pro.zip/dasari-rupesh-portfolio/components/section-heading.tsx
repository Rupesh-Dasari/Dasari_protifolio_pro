import Reveal from './reveal'

export default function SectionHeading({ title, intro }: { title: string; intro?: string }) {
  return (
    <Reveal className="mx-auto mb-14 max-w-3xl text-center">
      <h2 className="liquid-gradient font-display text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">{title}</h2>
      {intro && <p className="mt-5 text-lg text-pretty text-muted sm:text-xl">{intro}</p>}
    </Reveal>
  )
}
