import Image from 'next/image'
import { PROFILE } from '@/lib/data'

/** The hero photo: a clean gradient ring and a soft glow. */
export default function HolographicAvatar() {
  return (
    <div className="float relative mx-auto h-32 w-32 sm:h-44 sm:w-44">
      <div aria-hidden="true" className="absolute -inset-8 rounded-full bg-[radial-gradient(circle,var(--glow),transparent_68%)]" />
      <div id="hero-avatar" className="relative h-full w-full rounded-full bg-gradient-to-br from-g1 via-g2 to-g3 p-[3px] shadow-[0_20px_60px_-20px_var(--glow)]">
        <div className="h-full w-full overflow-hidden rounded-full bg-bg">
          <Image
            src={PROFILE.photo}
            alt={`Photo of ${PROFILE.name}`}
            priority
            placeholder="blur"
            sizes="176px"
            className="h-full w-full object-cover object-[50%_20%]"
          />
        </div>
      </div>
    </div>
  )
}
