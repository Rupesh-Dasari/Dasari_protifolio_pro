'use client'

import { useRef } from 'react'
import Image from 'next/image'
import { motion, useReducedMotion } from 'motion/react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import TiltCard from '@/components/tilt-card'
import type { Project } from '@/lib/data'
import { cn } from '@/lib/utils'

type Props = {
  projects: Project[]
  activeId: string
  onChange: (id: string) => void
  onOpen: () => void
}

/** Projects in a 3D coverflow: the active one faces you, the others angle away into depth. */
export default function ProjectCarousel({ projects, activeId, onChange, onOpen }: Props) {
  const reduced = useReducedMotion()
  const dragged = useRef(false)
  const n = projects.length
  const active = Math.max(0, projects.findIndex((p) => p.id === activeId))
  const go = (dir: number) => onChange(projects[(active + dir + n) % n].id)

  return (
    <div
      role="region"
      aria-roledescription="carousel"
      aria-label="Featured projects"
      className="relative"
      onKeyDown={(e) => {
        if (e.key === 'ArrowRight') go(1)
        if (e.key === 'ArrowLeft') go(-1)
      }}
    >
      {/* soft floor light under the cards */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-x-[10%] bottom-0 h-40 rounded-[100%] bg-[radial-gradient(ellipse_at_center,var(--glow),transparent_70%)] blur-2xl" />

      <motion.div
        className="relative mx-auto cursor-grab touch-pan-y active:cursor-grabbing"
        style={{ perspective: 1800 }}
        drag={reduced ? false : 'x'}
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.12}
        onDragStart={() => {
          dragged.current = true
        }}
        onDragEnd={(_, info) => {
          if (info.offset.x < -60) go(1)
          else if (info.offset.x > 60) go(-1)
          setTimeout(() => {
            dragged.current = false
          }, 0)
        }}
      >
        {/* sets the stage height to one card plus room for the reflection */}
        <div aria-hidden="true" className="invisible mx-auto aspect-video w-[min(84%,780px)] sm:w-[min(72%,780px)]" />
        <div aria-hidden="true" className="h-14 sm:h-20" />

        {projects.map((p, i) => {
          let off = i - active
          if (off > n / 2) off -= n
          if (off < -n / 2) off += n
          const isActive = off === 0
          return (
            <motion.div
              key={p.id}
              className="absolute top-0 left-1/2 w-[min(84%,780px)] sm:w-[min(72%,780px)]"
              initial={false}
              animate={{
                x: `${-50 + off * 64}%`,
                rotateY: off * -38,
                z: isActive ? 0 : -280,
                scale: isActive ? 1 : 0.84,
                opacity: Math.abs(off) > 1 ? 0 : isActive ? 1 : 0.85,
              }}
              transition={{ type: 'spring', stiffness: 110, damping: 20, mass: 0.9 }}
              style={{ zIndex: isActive ? 3 : 1, transformStyle: 'preserve-3d' }}
            >
              <TiltCard max={isActive ? 6 : 0} className="rounded-2xl">
                <button
                  type="button"
                  data-cursor={isActive ? 'View' : off > 0 ? 'Next' : 'Back'}
                  aria-label={isActive ? `View ${p.name} screenshot full size` : `Show ${p.name}`}
                  onClick={() => {
                    if (dragged.current) return
                    if (isActive) onOpen()
                    else onChange(p.id)
                  }}
                  className={cn(
                    'group block w-full overflow-hidden rounded-2xl ring-1 transition-shadow duration-500',
                    '[-webkit-box-reflect:below_10px_linear-gradient(transparent_62%,rgba(255,255,255,0.14))]',
                    isActive
                      ? 'ring-g2/50 shadow-[0_40px_80px_-30px_rgba(0,0,0,0.65),0_0_60px_-20px_var(--glow)]'
                      : 'ring-glass-line shadow-[0_30px_60px_-30px_rgba(0,0,0,0.6)]',
                  )}
                >
                  <Image
                    src={p.image}
                    alt={p.imageAlt}
                    placeholder="blur"
                    sizes="(max-width: 640px) 84vw, 780px"
                    draggable={false}
                    className={cn(
                      'aspect-video w-full object-cover transition-[transform,filter] duration-700 ease-out',
                      isActive ? 'group-hover:scale-[1.03]' : 'brightness-75 saturate-75',
                    )}
                  />
                </button>
              </TiltCard>
            </motion.div>
          )
        })}
      </motion.div>

      {/* arrows */}
      <button
        type="button"
        onClick={() => go(-1)}
        aria-label="Previous project"
        className="glass absolute top-[38%] left-0 z-10 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full text-ink transition-transform hover:scale-110 sm:left-2"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>
      <button
        type="button"
        onClick={() => go(1)}
        aria-label="Next project"
        className="glass absolute top-[38%] right-0 z-10 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full text-ink transition-transform hover:scale-110 sm:right-2"
      >
        <ChevronRight className="h-5 w-5" />
      </button>
    </div>
  )
}
