'use client'

import { useEffect, useState } from 'react'

const LINES = ['Initializing neural core', 'Loading projects', 'Systems online']

/** A short boot sequence. Pure CSS timing, so it always clears itself; click to skip. */
export default function Intro() {
  const [done, setDone] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setDone(true), 2400)
    return () => clearTimeout(t)
  }, [])

  if (done) return null
  return (
    <div aria-hidden="true" onClick={() => setDone(true)} className="intro fixed inset-0 z-[100] grid cursor-pointer place-items-center bg-bg">
      <div className="flex w-64 flex-col items-center">
        <div className="relative grid h-20 w-20 place-items-center">
          <div className="holo-ring absolute inset-0 rounded-full" />
          <span className="liquid-gradient font-display text-2xl font-bold">DR</span>
        </div>
        <div className="mt-8 h-[2px] w-full overflow-hidden rounded-full bg-line">
          <div className="intro-bar h-full bg-gradient-to-r from-g1 via-g2 to-g3" />
        </div>
        <ul className="mt-5 w-full space-y-1.5 font-mono text-xs text-muted">
          {LINES.map((line, i) => (
            <li key={line} className="intro-line flex justify-between" style={{ animationDelay: `${0.15 + i * 0.38}s` }}>
              <span>{line}</span>
              <span className="text-g1">OK</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
