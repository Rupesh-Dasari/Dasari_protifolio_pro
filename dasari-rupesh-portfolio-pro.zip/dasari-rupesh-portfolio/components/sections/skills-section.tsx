import { Brain, Code2, Database, Server, Sparkles, Workflow, Wrench } from 'lucide-react'
import SectionHeading from '@/components/section-heading'
import Reveal from '@/components/reveal'
import TiltCard from '@/components/tilt-card'
import SkillSphere from '@/components/skill-sphere'
import { SKILL_GROUPS } from '@/lib/data'

const ICONS = {
  code: Code2,
  server: Server,
  sparkles: Sparkles,
  workflow: Workflow,
  database: Database,
  brain: Brain,
  wrench: Wrench,
} as const

const sphereTags = SKILL_GROUPS.flatMap((group, gi) =>
  group.items.map((label) => ({ label, tone: ((gi % 3) + 1) as 1 | 2 | 3 })),
)

export default function SkillsSection() {
  return (
    <section id="skills" className="relative py-24 sm:py-32">
      <div aria-hidden="true" className="aurora top-20 -left-24 h-96 w-96 bg-g3" />
      <div className="relative mx-auto max-w-6xl px-5 sm:px-6">
        <SectionHeading title="Skills universe" intro="Move your mouse over the sphere to spin it." />

        <div className="grid items-start gap-10 lg:grid-cols-[1fr_1.05fr]">
          <Reveal className="lg:sticky lg:top-28">
            <SkillSphere tags={sphereTags} />
          </Reveal>

          <div className="grid gap-4 sm:grid-cols-2">
            {SKILL_GROUPS.map((group, i) => {
              const Icon = ICONS[group.icon]
              return (
                <Reveal key={group.name} delay={i * 0.05} className={i === SKILL_GROUPS.length - 1 ? 'h-full sm:col-span-2' : 'h-full'}>
                  <TiltCard max={9} className="glass spotlight h-full rounded-2xl p-5">
                    <div className="flex items-center gap-3">
                      <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-g1/20 via-g2/20 to-g3/20 text-g2">
                        <Icon className="h-[18px] w-[18px]" aria-hidden="true" />
                      </span>
                      <h3 className="font-display font-semibold">{group.name}</h3>
                    </div>
                    <ul className="mt-4 flex flex-wrap gap-1.5">
                      {group.items.map((item) => (
                        <li key={item} className="chip chip--sm">
                          {item}
                        </li>
                      ))}
                    </ul>
                  </TiltCard>
                </Reveal>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
