'use client'

import { useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { Briefcase, ChevronDown, GraduationCap } from 'lucide-react'
import SectionHeading from '@/components/section-heading'
import Reveal from '@/components/reveal'
import { TIMELINE } from '@/lib/data'
import { cn } from '@/lib/utils'

export default function JourneySection() {
  const [openId, setOpenId] = useState<string | null>(TIMELINE[0].id)

  return (
    <section id="journey" className="relative py-24 sm:py-32">
      <div aria-hidden="true" className="aurora top-1/3 -right-40 h-96 w-96 bg-g3" />
      <div className="relative mx-auto max-w-5xl px-5 sm:px-6">
        <SectionHeading title="My journey" intro="Work and education, newest first. Open any step for the details." />

        <div className="relative">
        {/* the glowing line, with a beam of light travelling down it */}
        <div
          aria-hidden="true"
          className="absolute top-2 bottom-2 left-5 w-px bg-gradient-to-b from-g1 via-g2 to-g3 md:left-1/2 md:-translate-x-1/2"
        >
          <span className="timeline-beam -left-px" />
        </div>
        <ol className="relative">
          {TIMELINE.map((item, index) => {
            const open = openId === item.id
            const Icon = item.kind === 'work' ? Briefcase : GraduationCap
            const right = index % 2 === 1
            return (
              <li key={item.id} className="relative pb-10 last:pb-0">
                {/* node */}
                <span
                  aria-hidden="true"
                  className={cn(
                    'absolute top-5 left-5 z-10 grid h-10 w-10 -translate-x-1/2 place-items-center rounded-full border border-glass-line bg-bg md:left-1/2',
                    open && 'shadow-[0_0_24px_var(--glow)]',
                  )}
                >
                  <Icon className={cn('h-[18px] w-[18px]', item.kind === 'work' ? 'text-g1' : 'text-g3')} />
                </span>

                <Reveal
                  delay={index * 0.05}
                  className={cn('pl-14 md:w-1/2 md:pl-0', right ? 'md:ml-auto md:pl-12' : 'md:pr-12')}
                >
                  <div className="glass glow-card spotlight rounded-2xl" data-active={open}>
                    <button
                      type="button"
                      onClick={() => setOpenId(open ? null : item.id)}
                      aria-expanded={open}
                      aria-controls={`journey-${item.id}`}
                      className="flex w-full items-start gap-4 rounded-2xl p-6 text-left"
                    >
                      <span className="flex-1">
                        <span className="block text-sm font-semibold text-g1">{item.dates}</span>
                        <span className="mt-1 block font-display text-xl font-semibold text-ink">{item.title}</span>
                        <span className="mt-1 block text-muted">{item.place}</span>
                      </span>
                      <ChevronDown
                        aria-hidden="true"
                        className={cn('mt-1 h-5 w-5 shrink-0 text-muted transition-transform duration-300', open && 'rotate-180')}
                      />
                    </button>
                    <AnimatePresence initial={false}>
                      {open && (
                        <motion.div
                          id={`journey-${item.id}`}
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                          className="overflow-hidden"
                        >
                          <div className="px-6 pb-6">
                            <ul className="space-y-2 border-t border-line pt-4 text-ink/90">
                              {item.details.map((d) => (
                                <li key={d} className="flex gap-3">
                                  <span aria-hidden="true" className="mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full bg-g2" />
                                  <span>{d}</span>
                                </li>
                              ))}
                            </ul>
                            <ul className="mt-4 flex flex-wrap gap-2" aria-label="Skills used">
                              {item.tags.map((t) => (
                                <li key={t} className="chip">
                                  {t}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </Reveal>
              </li>
            )
          })}
        </ol>
        </div>
      </div>
    </section>
  )
}
