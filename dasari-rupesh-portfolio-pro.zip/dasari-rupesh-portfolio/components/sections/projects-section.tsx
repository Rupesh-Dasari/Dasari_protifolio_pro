'use client'

import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import Image from 'next/image'
import { AnimatePresence, motion } from 'motion/react'
import { Brain, Coffee, ExternalLink, FileScan, X } from 'lucide-react'
import SectionHeading from '@/components/section-heading'
import Reveal from '@/components/reveal'
import TiltCard from '@/components/tilt-card'
import ProjectCarousel from '@/components/project-carousel'
import { GitHubIcon } from '@/components/brand-icons'
import { PROJECTS } from '@/lib/data'
import { cn } from '@/lib/utils'

const ICONS = { b2i: FileScan, brain: Brain, cafe: Coffee } as const

export default function ProjectsSection() {
  const [selectedId, setSelectedId] = useState(PROJECTS[0].id)
  const [zoomed, setZoomed] = useState(false)
  const closeRef = useRef<HTMLButtonElement>(null)
  const hoverTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const project = PROJECTS.find((p) => p.id === selectedId) ?? PROJECTS[0]

  // Hovering a project button (with a mouse) brings that project to the front
  const previewOnHover = (id: string) => (e: React.PointerEvent) => {
    if (e.pointerType !== 'mouse') return
    if (hoverTimer.current) clearTimeout(hoverTimer.current)
    hoverTimer.current = setTimeout(() => setSelectedId(id), 120)
  }
  const cancelHover = () => {
    if (hoverTimer.current) clearTimeout(hoverTimer.current)
  }

  // Full-size screenshot viewer: Esc closes it, focus moves to the close button
  useEffect(() => {
    if (!zoomed) return
    closeRef.current?.focus()
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setZoomed(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [zoomed])

  return (
    <section id="projects" className="relative py-24 sm:py-32">
      <div aria-hidden="true" className="aurora top-1/4 left-1/3 h-[28rem] w-[28rem] bg-g2" />
      <div className="relative mx-auto max-w-6xl px-5 sm:px-6">
        <SectionHeading
          title="Featured projects"
          intro="Drag, swipe or use the arrows to move through my work. Click the front project to see it full size."
        />

        <Reveal>
          <ProjectCarousel projects={PROJECTS} activeId={selectedId} onChange={setSelectedId} onOpen={() => setZoomed(true)} />
        </Reveal>

        <Reveal delay={0.05}>
          <div role="group" aria-label="Choose a project" className="mx-auto mt-8 grid max-w-3xl gap-2 sm:grid-cols-3">
            {PROJECTS.map((p) => {
              const active = p.id === selectedId
              const Icon = ICONS[p.id as keyof typeof ICONS] ?? FileScan
              return (
                <button
                  key={p.id}
                  type="button"
                  aria-pressed={active}
                  onClick={() => setSelectedId(p.id)}
                  onPointerEnter={previewOnHover(p.id)}
                  onPointerLeave={cancelHover}
                  className={cn(
                    'glass spotlight group relative flex min-h-16 items-center gap-3 rounded-2xl p-3 text-left transition-all duration-300 hover:-translate-y-1',
                    active ? 'ring-1 ring-g2/60 shadow-[0_0_30px_-10px_var(--glow)]' : '',
                  )}
                >
                  <span
                    className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6"
                    style={{ background: `linear-gradient(135deg, ${p.color}, var(--g2))` }}
                  >
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <span className={cn('min-w-0 text-sm leading-snug font-semibold', active ? 'text-ink' : 'text-ink/80')}>{p.name}</span>
                </button>
              )
            })}
          </div>
        </Reveal>

        <Reveal delay={0.1} className="mt-8">
          <TiltCard max={2.5} className="rounded-3xl">
            <AnimatePresence mode="wait">
              <motion.article
                key={project.id}
                initial={{ opacity: 0, y: 16, rotateX: 8, filter: 'blur(6px)' }}
                animate={{ opacity: 1, y: 0, rotateX: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, y: -12, filter: 'blur(6px)' }}
                transition={{ duration: 0.35 }}
                className="glass spotlight grid gap-8 rounded-3xl p-6 sm:p-8 md:grid-cols-[1.5fr_1fr]"
                aria-live="polite"
              >
                <div>
                  <p className="flex items-center gap-2 text-sm font-medium text-muted">
                    <span aria-hidden="true" className="h-2.5 w-2.5 rounded-full" style={{ background: project.color }} />
                    {project.context}
                  </p>
                  <h3 className="mt-2 font-display text-2xl font-bold tracking-tight sm:text-3xl">{project.name}</h3>
                  <p className="mt-1 font-medium text-g2">{project.tagline}</p>
                  <p className="mt-4 text-pretty text-ink/90">{project.description}</p>
                  <ul className="mt-4 space-y-2 text-ink/85">
                    {project.points.map((pt) => (
                      <li key={pt} className="flex gap-3">
                        <span aria-hidden="true" className="mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full bg-g1" />
                        <span>{pt}</span>
                      </li>
                    ))}
                  </ul>
                  </div>
                <div className="flex flex-col md:border-l md:border-glass-line md:pl-8">
                  <h4 className="text-sm font-semibold text-muted">Built with</h4>
                  <ul className="mt-3 flex flex-wrap gap-2" aria-label="Built with">
                    {project.stack.map((s) => (
                      <li key={s} className="chip">
                        {s}
                      </li>
                    ))}
                  </ul>
                  {(project.demo || project.link) && (
                    <div className="mt-6 flex flex-wrap gap-3 md:mt-auto md:pt-6">
                      {project.demo && (
                        <a
                          href={project.demo}
                          data-cursor="Open"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex min-h-11 items-center gap-2 rounded-full bg-btn px-5 text-sm font-semibold text-btn-ink shadow-[0_0_32px_-8px_var(--glow)] transition-transform hover:scale-[1.04]"
                        >
                          <span className="relative inline-flex h-2 w-2">
                            <span className="live-dot relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                          </span>
                          Live demo
                          <ExternalLink className="h-4 w-4" aria-hidden="true" />
                        </a>
                      )}
                      {project.link && (
                        <a
                          href={project.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={cn(
                            'inline-flex min-h-11 items-center gap-2 rounded-full px-5 text-sm font-semibold transition-transform hover:scale-[1.04]',
                            project.demo ? 'glass text-ink' : 'bg-btn text-btn-ink',
                          )}
                        >
                          <GitHubIcon className="h-4 w-4" />
                          View on GitHub
                        </a>
                      )}
                    </div>
                  )}
                
                </div>
              </motion.article>
            </AnimatePresence>
          </TiltCard>
        </Reveal>
      </div>

      {typeof document !== 'undefined' &&
        createPortal(
      <AnimatePresence>
        {zoomed && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={`${project.name} screenshot`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setZoomed(false)}
            className="fixed inset-0 z-[90] grid place-items-center bg-black/80 p-4 pt-[calc(1rem+env(safe-area-inset-top,0px))] backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.94, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.96, opacity: 0 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="relative w-[min(94vw,1400px)]"
              onClick={(e) => e.stopPropagation()}
            >
              <Image src={project.image} alt={project.imageAlt} sizes="94vw" className="h-auto w-full rounded-2xl shadow-2xl" />
              <button
                ref={closeRef}
                type="button"
                onClick={() => setZoomed(false)}
                aria-label="Close"
                className="absolute -top-3 -right-3 grid h-11 w-11 place-items-center rounded-full bg-white text-slate-900 shadow-lg sm:-top-4 sm:-right-4"
              >
                <X className="h-5 w-5" />
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>,
          document.body,
        )}
    </section>
  )
}
