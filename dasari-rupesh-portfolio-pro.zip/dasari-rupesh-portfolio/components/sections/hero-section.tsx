'use client'

import { motion } from 'motion/react'
import { ArrowDown, Download, Mail, MapPin } from 'lucide-react'
import HolographicAvatar from '@/components/holographic-avatar'
import Typewriter from '@/components/typewriter'
import { GitHubIcon, LinkedInIcon } from '@/components/brand-icons'
import Magnetic from '@/components/magnetic'
import { PROFILE, TYPED_PHRASES } from '@/lib/data'

// Hero animations start as the intro sequence fades out
const INTRO = 1.6

const rise = (delay: number) => ({
  initial: { opacity: 0, y: 24, filter: 'blur(8px)' },
  animate: { opacity: 1, y: 0, filter: 'blur(0px)' },
  transition: { delay: INTRO + delay, duration: 0.8, ease: [0.22, 1, 0.36, 1] as const },
})

export default function HeroSection() {
  return (
    <section
      id="home"
      className="relative flex min-h-[100svh] items-center justify-center overflow-hidden pt-[calc(6rem+env(safe-area-inset-top,0px))] pb-24"
    >
      {/* soft shade behind the text so it stays readable over the 3D scene */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-[38%] mx-auto h-[55%] max-w-4xl bg-[radial-gradient(ellipse_at_center,color-mix(in_srgb,var(--bg)_70%,transparent),transparent_70%)]"
      />

      <div className="relative z-10 mx-auto w-full max-w-4xl px-6 text-center">
        <motion.div initial={{ opacity: 0, scale: 0.4 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: INTRO - 0.1, duration: 1, ease: [0.22, 1, 0.36, 1] }}>
          <HolographicAvatar />
        </motion.div>

        <motion.p {...rise(0.45)} className="mt-12 inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-sm text-muted sm:mt-14">
          <MapPin className="h-4 w-4 text-g1" aria-hidden="true" />
          {PROFILE.location}
        </motion.p>

        <motion.h1
          {...rise(0.6)}
          className="mt-5 font-display text-5xl leading-[1.05] font-bold tracking-tight text-ink sm:text-7xl md:text-8xl"
        >
          {PROFILE.name}
        </motion.h1>

        <motion.p {...rise(0.75)} className="mt-5 font-display text-xl font-medium text-ink sm:text-2xl">
          {PROFILE.role}
        </motion.p>

        <motion.p {...rise(0.9)} className="mx-auto mt-4 min-h-[2.5em] max-w-2xl text-lg text-muted sm:text-xl">
          I build <Typewriter phrases={TYPED_PHRASES} />
        </motion.p>

        <motion.div {...rise(1.05)} className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Magnetic>
          <a
            href="#projects"
            className="group inline-flex min-h-12 items-center gap-2 rounded-full bg-btn px-7 text-base font-semibold text-btn-ink shadow-[0_0_40px_-8px_var(--glow)] transition-transform hover:scale-[1.04]"
          >
            Explore my work
            <ArrowDown className="h-4 w-4 transition-transform group-hover:translate-y-0.5" aria-hidden="true" />
          </a>
          </Magnetic>
<Magnetic>
          <a
            href={PROFILE.resume}
            download
            className="glass spotlight inline-flex min-h-12 items-center gap-2 rounded-full px-7 text-base font-semibold text-ink transition-transform hover:scale-[1.04]"
          >
            <Download className="h-4 w-4" aria-hidden="true" />
            Download resume
          </a>
          </Magnetic>
        </motion.div>

        <motion.div {...rise(1.2)} className="mt-7 flex items-center justify-center gap-3">
          <Magnetic strength={0.45}><a href={PROFILE.github} target="_blank" rel="noopener noreferrer" aria-label="GitHub" className="glass spotlight grid h-11 w-11 place-items-center rounded-full text-ink transition-colors hover:text-g2">
            <GitHubIcon className="h-5 w-5" />
          </a></Magnetic>
          <Magnetic strength={0.45}><a href={PROFILE.linkedin} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" className="glass spotlight grid h-11 w-11 place-items-center rounded-full text-ink transition-colors hover:text-g2">
            <LinkedInIcon className="h-5 w-5" />
          </a></Magnetic>
          <Magnetic strength={0.45}><a href={`mailto:${PROFILE.email}`} aria-label="Email" className="glass spotlight grid h-11 w-11 place-items-center rounded-full text-ink transition-colors hover:text-g2">
            <Mail className="h-5 w-5" />
          </a></Magnetic>
        </motion.div>
      </div>

      <motion.a
        href="#about"
        aria-label="Scroll to About"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: INTRO + 1.8, duration: 1 }}
        className="absolute bottom-[calc(1.5rem+env(safe-area-inset-bottom,0px))] left-1/2 z-10 -translate-x-1/2"
      >
        <span className="flex h-11 w-7 justify-center rounded-full border-2 border-muted/40 pt-2">
          <span className="scroll-wheel h-2.5 w-1 rounded-full bg-g1" />
        </span>
      </motion.a>
    </section>
  )
}
