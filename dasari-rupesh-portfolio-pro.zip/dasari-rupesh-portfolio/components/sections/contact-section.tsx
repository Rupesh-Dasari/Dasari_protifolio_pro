'use client'

import { useState } from 'react'
import { Download, Mail, MapPin, Phone, Send } from 'lucide-react'
import SectionHeading from '@/components/section-heading'
import Reveal from '@/components/reveal'
import { GitHubIcon, LinkedInIcon } from '@/components/brand-icons'
import { PROFILE } from '@/lib/data'

const CHANNELS = [
  { label: 'Email', value: PROFILE.email, href: `mailto:${PROFILE.email}`, Icon: Mail },
  { label: 'Phone', value: PROFILE.phone, href: PROFILE.phoneLink, Icon: Phone },
  { label: 'LinkedIn', value: 'dasari-rupesh', href: PROFILE.linkedin, Icon: LinkedInIcon, external: true },
  { label: 'GitHub', value: 'Rupesh-Dasari', href: PROFILE.github, Icon: GitHubIcon, external: true },
]

const inputClass =
  'mt-2 w-full rounded-xl border border-glass-line bg-glass px-4 py-3 text-ink placeholder:text-muted/70 outline-none transition-shadow focus:border-g2 focus:shadow-[0_0_0_4px_color-mix(in_srgb,var(--g2)_20%,transparent)]'

export default function ContactSection() {
  const [sent, setSent] = useState(false)

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const data = new FormData(e.currentTarget)
    const name = String(data.get('name') ?? '').trim()
    const email = String(data.get('email') ?? '').trim()
    const message = String(data.get('message') ?? '').trim()
    const subject = `Portfolio enquiry from ${name}`
    const body = `${message}\n\n${name}\n${email}`
    window.location.href = `mailto:${PROFILE.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
    setSent(true)
  }

  return (
    <section id="contact" className="relative py-24 sm:py-32">
      <div aria-hidden="true" className="aurora bottom-10 left-1/2 h-96 w-96 -translate-x-1/2 bg-g2" />
      <div className="relative mx-auto max-w-6xl px-5 sm:px-6">
        <SectionHeading
          title="Let’s connect"
          intro="Have a backend, AI or automation problem, or a role you think I’d fit? I’d like to hear about it."
        />

        <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
          <Reveal className="flex flex-col gap-3">
            {CHANNELS.map(({ label, value, href, Icon, external }) => (
              <a
                key={label}
                href={href}
                {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                className="glass spotlight group flex items-center gap-4 rounded-2xl p-5 transition-transform duration-300 hover:-translate-y-1"
              >
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-g1 via-g2 to-g3 text-white transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6">
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <span className="min-w-0">
                  <span className="block text-sm text-muted">{label}</span>
                  <span className="block truncate font-semibold text-ink">{value}</span>
                </span>
              </a>
            ))}
            <div className="glass flex items-center gap-4 rounded-2xl p-5">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-glass-line text-g1">
                <MapPin className="h-5 w-5" aria-hidden="true" />
              </span>
              <span>
                <span className="block text-sm text-muted">Based in</span>
                <span className="block font-semibold">{PROFILE.location}</span>
              </span>
            </div>
          </Reveal>

          <Reveal delay={0.1}>
            <form onSubmit={onSubmit} className="glass spotlight rounded-3xl p-6 sm:p-8">
              <h3 className="font-display text-2xl font-semibold">Send a message</h3>
              <p className="mt-1 text-muted">This opens your email app with the message filled in.</p>
              <div className="mt-6 grid gap-5 sm:grid-cols-2">
                <label className="block text-sm font-medium">
                  Your name
                  <input name="name" required autoComplete="name" className={inputClass} placeholder="Priya Sharma" />
                </label>
                <label className="block text-sm font-medium">
                  Your email
                  <input name="email" type="email" required autoComplete="email" className={inputClass} placeholder="priya@company.com" />
                </label>
              </div>
              <label className="mt-5 block text-sm font-medium">
                Message
                <textarea name="message" required rows={5} className={`${inputClass} resize-y`} placeholder="Tell me about the project or role" />
              </label>
              <div className="mt-6 flex flex-wrap items-center gap-4">
                <button
                  type="submit"
                  className="inline-flex min-h-12 items-center gap-2 rounded-full bg-btn px-7 font-semibold text-btn-ink shadow-[0_0_40px_-8px_var(--glow)] transition-transform hover:scale-[1.03]"
                >
                  <Send className="h-4 w-4" aria-hidden="true" />
                  Open in email app
                </button>
                <a href={PROFILE.resume} download className="inline-flex min-h-12 items-center gap-2 font-semibold text-ink underline decoration-g2 decoration-2 underline-offset-4 hover:text-g2">
                  <Download className="h-4 w-4" aria-hidden="true" />
                  Download resume
                </a>
              </div>
              <p role="status" className="mt-4 min-h-6 text-sm text-muted">
                {sent ? 'Your email app should now be open with the message ready to send.' : ''}
              </p>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
