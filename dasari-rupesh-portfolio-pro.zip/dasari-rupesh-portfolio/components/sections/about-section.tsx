import { Award, Briefcase, Hammer } from 'lucide-react'
import Reveal from '@/components/reveal'
import TiltCard from '@/components/tilt-card'
import SectionHeading from '@/components/section-heading'
import { ABOUT, CERTIFICATIONS, NOW, QUICK_FACTS } from '@/lib/data'

export default function AboutSection() {
  return (
    <section id="about" className="relative py-24 sm:py-32">
      <div aria-hidden="true" className="aurora top-10 -left-32 h-80 w-80 bg-g1" />
      <div className="relative mx-auto max-w-6xl px-5 sm:px-6">
        <SectionHeading title="About me" intro="Backend engineer by training, automation builder by choice." />

        <div className="grid gap-6 lg:grid-cols-[1.25fr_1fr]">
          <Reveal className="h-full">
          <TiltCard max={4} className="glass spotlight flex h-full flex-col rounded-3xl p-7 sm:p-9">
            <div className="space-y-5 text-lg leading-relaxed text-pretty text-ink/90">
              {ABOUT.map((p) => (
                <p key={p}>{p}</p>
              ))}
            </div>
            <dl className="mt-10 grid grid-cols-3 gap-3 lg:mt-auto lg:pt-10">
              {QUICK_FACTS.map((f) => (
                <div key={f.label} className="rounded-2xl border border-glass-line bg-glass p-4 text-center">
                  <dt className="sr-only">{f.label}</dt>
                  <dd className="liquid-gradient font-display text-2xl font-bold sm:text-3xl">{f.value}</dd>
                  <dd aria-hidden="true" className="mt-1 text-xs text-muted sm:text-sm">{f.label}</dd>
                </div>
              ))}
            </dl>
          </TiltCard>
          </Reveal>

          <div className="grid gap-6">
            <Reveal delay={0.1}>
            <TiltCard className="glass spotlight rounded-3xl p-7">
              <div className="flex items-center gap-3">
                <span className="relative inline-flex h-2.5 w-2.5">
                  <span className="live-dot relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-400" />
                </span>
                <h3 className="font-display text-lg font-semibold">Right now</h3>
              </div>
              <dl className="mt-5 space-y-4">
                <div className="flex gap-3">
                  <Briefcase className="mt-0.5 h-5 w-5 shrink-0 text-g1" aria-hidden="true" />
                  <div>
                    <dt className="sr-only">Role</dt>
                    <dd className="font-medium">{NOW.title}</dd>
                    <dd className="text-muted">{NOW.company}</dd>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Hammer className="mt-0.5 h-5 w-5 shrink-0 text-g3" aria-hidden="true" />
                  <div>
                    <dt className="text-muted">Building</dt>
                    <dd className="font-medium">{NOW.building}</dd>
                  </div>
                </div>
              </dl>
              <ul className="mt-5 flex flex-wrap gap-2" aria-label="Current stack">
                {NOW.stack.map((s) => (
                  <li key={s} className="chip">
                    {s}
                  </li>
                ))}
              </ul>
            </TiltCard>
            </Reveal>

            <Reveal delay={0.2}>
            <TiltCard className="glass spotlight rounded-3xl p-7">
              <div className="flex items-center gap-3">
                <Award className="h-5 w-5 text-g2" aria-hidden="true" />
                <h3 className="font-display text-lg font-semibold">Certifications & activities</h3>
              </div>
              <ul className="mt-4 space-y-3">
                {CERTIFICATIONS.map((c) => (
                  <li key={c.name} className="border-t border-line pt-3 first:border-t-0 first:pt-0">
                    <p className="font-medium">{c.name}</p>
                    <p className="text-sm text-muted">{c.detail}</p>
                  </li>
                ))}
              </ul>
            </TiltCard>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  )
}
