'use client'

import { useEffect, useRef } from 'react'
import { useReducedMotion } from 'motion/react'

/** A soft light that follows the mouse, and the glowing card borders that track it. */
export default function CursorGlow() {
  const ref = useRef<HTMLDivElement>(null)
  const reduced = useReducedMotion()

  useEffect(() => {
    let frame = 0
    let x = -1000
    let y = -1000
    let target: Element | null = null
    const onMove = (e: PointerEvent) => {
      if (e.pointerType !== 'mouse') return
      x = e.clientX
      y = e.clientY
      target = e.target as Element
      if (frame) return
      frame = requestAnimationFrame(() => {
        frame = 0
        if (!reduced) {
          ref.current?.style.setProperty('--x', `${x}px`)
          ref.current?.style.setProperty('--y', `${y}px`)
        }
        // every .spotlight card under the mouse gets the pointer position
        let el = target instanceof Element ? target.closest<HTMLElement>('.spotlight') : null
        while (el) {
          const r = el.getBoundingClientRect()
          el.style.setProperty('--mx', `${x - r.left}px`)
          el.style.setProperty('--my', `${y - r.top}px`)
          el = el.parentElement?.closest<HTMLElement>('.spotlight') ?? null
        }
      })
    }
    window.addEventListener('pointermove', onMove, { passive: true })
    return () => {
      window.removeEventListener('pointermove', onMove)
      cancelAnimationFrame(frame)
    }
  }, [reduced])

  if (reduced) return null
  return (
    <div
      ref={ref}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-[1] bg-[radial-gradient(480px_circle_at_var(--x,-1000px)_var(--y,-1000px),var(--glow),transparent_45%)] opacity-50"
    />
  )
}
