import { ArrowUp } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="border-t border-line">
      <div className="mx-auto flex max-w-6xl justify-center px-5 py-8 pb-[calc(2rem+env(safe-area-inset-bottom,0px))] sm:px-6">
        <a href="#home" className="glass inline-flex min-h-10 items-center gap-2 rounded-full px-4 text-sm text-ink hover:text-g2">
          <ArrowUp className="h-4 w-4" aria-hidden="true" />
          Back to top
        </a>
      </div>
    </footer>
  )
}
