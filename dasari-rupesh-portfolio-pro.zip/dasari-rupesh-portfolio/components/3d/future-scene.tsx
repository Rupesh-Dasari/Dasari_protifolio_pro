'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { useReducedMotion } from 'motion/react'
import { seededRandom } from '@/lib/utils'
import { makeGlowTexture } from '@/lib/three-utils'
import { useWebGL } from '@/hooks/use-webgl'

const FOV = 50
const CAMERA_Z = 10

type Palette = {
  bg: string
  node: string
  line: string
  pulse: string
  ringA: string
  ringB: string
  ringC: string
  wire: string
  core: string
  stars: string[]
  grid: string
  gridCenter: string
  additive: boolean
}

const DARK: Palette = {
  bg: '#05070f',
  node: '#c7d2fe',
  line: '#818cf8',
  pulse: '#67e8f9',
  ringA: '#38bdf8',
  ringB: '#e879f9',
  ringC: '#818cf8',
  wire: '#a5b4fc',
  core: '#818cf8',
  stars: ['#e0e7ff', '#67e8f9', '#f0abfc', '#a5b4fc'],
  grid: '#3b3f9e',
  gridCenter: '#e879f9',
  additive: true,
}

const LIGHT: Palette = {
  bg: '#f4f6fc',
  node: '#4338ca',
  line: '#6366f1',
  pulse: '#c026d3',
  ringA: '#0284c7',
  ringB: '#c026d3',
  ringC: '#4f46e5',
  wire: '#6366f1',
  core: '#818cf8',
  stars: ['#6366f1', '#0284c7', '#c026d3', '#94a3b8'],
  grid: '#c7cbe8',
  gridCenter: '#c026d3',
  additive: false,
}

/* ---------------- Neural core around the hero photo ---------------- */

function NeuralCore({ palette, animate, anchorId }: { palette: Palette; animate: boolean; anchorId: string }) {
  const group = useRef<THREE.Group>(null!)
  const spin = useRef<THREE.Group>(null!)
  const rings = useRef<(THREE.Mesh | null)[]>([])
  const pulsesRef = useRef<THREE.Points>(null!)
  const anchor = useRef<HTMLElement | null>(null)
  const glow = useMemo(() => makeGlowTexture(), [])
  const blending = palette.additive ? THREE.AdditiveBlending : THREE.NormalBlending

  const net = useMemo(() => {
    const rand = seededRandom(21)
    const N = 150
    const golden = Math.PI * (3 - Math.sqrt(5))
    const nodes: THREE.Vector3[] = []
    for (let i = 0; i < N; i++) {
      const y = 1 - (i / (N - 1)) * 2
      const r = Math.sqrt(1 - y * y)
      const t = golden * i
      const radius = 0.92 + rand() * 0.14
      nodes.push(new THREE.Vector3(Math.cos(t) * r * radius, y * radius, Math.sin(t) * r * radius))
    }
    // connect each node to its 3 nearest neighbours
    const edgeSet = new Set<string>()
    const edges: [number, number][] = []
    nodes.forEach((a, i) => {
      const nearest = nodes
        .map((b, j) => ({ j, d: i === j ? Infinity : a.distanceToSquared(b) }))
        .sort((x, y) => x.d - y.d)
        .slice(0, 3)
      nearest.forEach(({ j }) => {
        const key = i < j ? `${i}-${j}` : `${j}-${i}`
        if (!edgeSet.has(key)) {
          edgeSet.add(key)
          edges.push([Math.min(i, j), Math.max(i, j)])
        }
      })
    })
    const adjacency: number[][] = nodes.map(() => [])
    edges.forEach(([a, b], e) => {
      adjacency[a].push(e)
      adjacency[b].push(e)
    })
    const linePos = new Float32Array(edges.length * 6)
    edges.forEach(([a, b], e) => {
      linePos.set([nodes[a].x, nodes[a].y, nodes[a].z, nodes[b].x, nodes[b].y, nodes[b].z], e * 6)
    })
    const nodePos = new Float32Array(N * 3)
    nodes.forEach((n, i) => nodePos.set([n.x, n.y, n.z], i * 3))

    const lineGeo = new THREE.BufferGeometry()
    lineGeo.setAttribute('position', new THREE.BufferAttribute(linePos, 3))
    const nodeGeo = new THREE.BufferGeometry()
    nodeGeo.setAttribute('position', new THREE.BufferAttribute(nodePos, 3))
    return { nodes, edges, adjacency, lineGeo, nodeGeo }
  }, [])

  // Signals travelling along the network
  const PULSES = 10
  const pulses = useMemo(() => {
    const rand = seededRandom(5)
    const state = Array.from({ length: PULSES }, () => {
      const edge = Math.floor(rand() * net.edges.length)
      return { edge, from: net.edges[edge][0], t: rand(), speed: 0.6 + rand() * 1.1 }
    })
    const geo = new THREE.BufferGeometry()
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(PULSES * 3), 3))
    return { state, geo }
  }, [net])

  useEffect(
    () => () => {
      net.lineGeo.dispose()
      net.nodeGeo.dispose()
      pulses.geo.dispose()
    },
    [net, pulses],
  )

  useFrame((state, delta) => {
    // Keep the core centred behind the photo, at a size relative to it
    if (!anchor.current) anchor.current = document.getElementById(anchorId)
    const el = anchor.current
    if (el) {
      const r = el.getBoundingClientRect()
      const w = state.size.width
      const h = state.size.height
      const halfH = Math.tan(THREE.MathUtils.degToRad(FOV / 2)) * CAMERA_Z
      const halfW = halfH * (w / h)
      const nx = ((r.left + r.width / 2) / w) * 2 - 1
      const ny = -(((r.top + r.height / 2) / h) * 2 - 1)
      group.current.position.set(nx * halfW, ny * halfH, 0)
      const worldPerPx = (2 * halfH) / h
      group.current.scale.setScalar(r.width * 0.62 * worldPerPx)
      group.current.visible = r.bottom > -r.height * 2 && r.top < h + r.height * 2
    }
    if (!animate) return

    spin.current.rotation.y += delta * 0.08
    const rr = rings.current
    if (rr[0]) rr[0].rotation.z += delta * 0.15

    const arr = pulses.geo.attributes.position.array as Float32Array
    pulses.state.forEach((p, k) => {
      p.t += delta * p.speed
      if (p.t >= 1) {
        const [a, b] = net.edges[p.edge]
        const node = p.from === a ? b : a
        const options = net.adjacency[node]
        p.edge = options[Math.floor(Math.random() * options.length)]
        p.from = node
        p.t = 0
      }
      const [a, b] = net.edges[p.edge]
      const start = net.nodes[p.from]
      const end = net.nodes[p.from === a ? b : a]
      arr[k * 3] = start.x + (end.x - start.x) * p.t
      arr[k * 3 + 1] = start.y + (end.y - start.y) * p.t
      arr[k * 3 + 2] = start.z + (end.z - start.z) * p.t
    })
    pulses.geo.attributes.position.needsUpdate = true
  })

  return (
    <group ref={group}>
      <sprite scale={[3.2, 3.2, 1]}>
        <spriteMaterial map={glow} color={palette.core} transparent opacity={palette.additive ? 0.3 : 0.18} depthWrite={false} blending={blending} />
      </sprite>
      <group ref={spin}>
        <lineSegments geometry={net.lineGeo}>
          <lineBasicMaterial color={palette.line} transparent opacity={palette.additive ? 0.12 : 0.12} depthWrite={false} blending={blending} />
        </lineSegments>
        <points geometry={net.nodeGeo}>
          <pointsMaterial color={palette.node} size={0.05} sizeAttenuation map={glow} transparent opacity={0.45} depthWrite={false} blending={blending} />
        </points>
        <points ref={pulsesRef} geometry={pulses.geo}>
          <pointsMaterial color={palette.pulse} size={0.12} sizeAttenuation map={glow} transparent opacity={0.6} depthWrite={false} blending={blending} />
        </points>
      </group>
      {/* one faint orbit ring */}
      <mesh ref={(m) => { rings.current[0] = m }} rotation={[Math.PI / 2.3, 0, 0]}>
        <torusGeometry args={[1.42, 0.005, 8, 200]} />
        <meshBasicMaterial color={palette.ringA} transparent opacity={0.3} depthWrite={false} />
      </mesh>
    </group>
  )
}

/* ---------------- Calm, twinkling starfield with depth ---------------- */

function StarField({ palette, animate }: { palette: Palette; animate: boolean }) {
  const group = useRef<THREE.Group>(null!)
  const matA = useRef<THREE.PointsMaterial>(null!)
  const matB = useRef<THREE.PointsMaterial>(null!)
  const glow = useMemo(() => makeGlowTexture(), [])

  const layers = useMemo(() => {
    const make = (seed: number, count: number) => {
      const rand = seededRandom(seed)
      const pos = new Float32Array(count * 3)
      const col = new Float32Array(count * 3)
      const c = new THREE.Color()
      for (let i = 0; i < count; i++) {
        pos.set([(rand() - 0.5) * 70, (rand() - 0.5) * 90 - 25, -60 + rand() * 62], i * 3)
        c.set(palette.stars[i % palette.stars.length])
        col.set([c.r, c.g, c.b], i * 3)
      }
      const g = new THREE.BufferGeometry()
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
      g.setAttribute('color', new THREE.BufferAttribute(col, 3))
      return g
    }
    return [make(77, 1300), make(78, 500)]
  }, [palette])
  useEffect(() => () => layers.forEach((g) => g.dispose()), [layers])

  useFrame((state, delta) => {
    const t = state.clock.elapsedTime
    if (animate) group.current.rotation.z += delta * 0.006
    // stars drift up gently as the page scrolls (depth parallax, no streaks)
    group.current.position.y = window.scrollY * 0.0018
    group.current.rotation.y = THREE.MathUtils.lerp(group.current.rotation.y, state.pointer.x * 0.04, 0.04)
    group.current.rotation.x = THREE.MathUtils.lerp(group.current.rotation.x, -state.pointer.y * 0.03, 0.04)
    if (animate) {
      matA.current.opacity = 0.65 + Math.sin(t * 1.3) * 0.2
      matB.current.opacity = 0.55 + Math.sin(t * 0.8 + 2) * 0.35
    }
  })

  const blending = palette.additive ? THREE.AdditiveBlending : THREE.NormalBlending
  return (
    <group ref={group}>
      <points geometry={layers[0]}>
        <pointsMaterial ref={matA} size={0.09} vertexColors map={glow} transparent opacity={0.7} depthWrite={false} blending={blending} sizeAttenuation />
      </points>
      <points geometry={layers[1]}>
        <pointsMaterial ref={matB} size={0.18} vertexColors map={glow} transparent opacity={0.6} depthWrite={false} blending={blending} sizeAttenuation />
      </points>
    </group>
  )
}

/* ---------------- Floating wireframe crystals down the page ---------------- */

const SHAPES = [
  { kind: 'ico', x: -11, y: 1.5, z: -7, s: 1.2 },
  { kind: 'octa', x: 11.5, y: -4, z: -8, s: 1.3 },
  { kind: 'torus', x: -11.5, y: -10, z: -7, s: 1 },
  { kind: 'tetra', x: 11, y: -15, z: -6, s: 1 },
  { kind: 'dodeca', x: -11, y: -21, z: -9, s: 1.3 },
  { kind: 'knot', x: 11, y: -27, z: -7, s: 0.8 },
  { kind: 'octa', x: -11.5, y: -33, z: -7, s: 1 },
  { kind: 'ico', x: 11.5, y: -39, z: -8, s: 1.4 },
  { kind: 'torus', x: -11, y: -46, z: -7, s: 1.1 },
  { kind: 'dodeca', x: 11.5, y: -52, z: -7, s: 1 },
] as const

function makeShape(kind: (typeof SHAPES)[number]['kind']) {
  switch (kind) {
    case 'ico':
      return new THREE.IcosahedronGeometry(1, 0)
    case 'octa':
      return new THREE.OctahedronGeometry(1, 0)
    case 'tetra':
      return new THREE.TetrahedronGeometry(1, 0)
    case 'dodeca':
      return new THREE.DodecahedronGeometry(1, 0)
    case 'torus':
      return new THREE.TorusGeometry(0.8, 0.28, 8, 18)
    case 'knot':
      return new THREE.TorusKnotGeometry(0.7, 0.2, 64, 8)
  }
}

function FloatingShapes({ palette, animate }: { palette: Palette; animate: boolean }) {
  const group = useRef<THREE.Group>(null!)
  const items = useRef<(THREE.Group | null)[]>([])
  const geos = useMemo(
    () => SHAPES.map((sh) => {
      const g = makeShape(sh.kind)
      const edges = new THREE.EdgesGeometry(g, 1)
      g.dispose()
      return edges
    }),
    [],
  )
  useEffect(() => () => geos.forEach((g) => g.dispose()), [geos])
  const colors = [palette.ringA, palette.ringC, palette.ringB]

  useFrame((state, delta) => {
    const h = state.size.height || 1
    const worldPerPx = (2 * Math.tan(THREE.MathUtils.degToRad(FOV / 2)) * CAMERA_Z) / h
    // crystals scroll slower than the page, so they feel further away
    group.current.position.y = window.scrollY * worldPerPx * 0.85
    group.current.position.x = THREE.MathUtils.lerp(group.current.position.x, state.pointer.x * 0.4, 0.04)
    if (!animate) return
    const t = state.clock.elapsedTime
    items.current.forEach((g, i) => {
      if (!g) return
      g.rotation.x += delta * (0.12 + i * 0.01)
      g.rotation.y += delta * (0.16 - i * 0.008)
      g.position.y = SHAPES[i].y + Math.sin(t * 0.6 + i) * 0.25
    })
  })

  return (
    <group ref={group}>
      {SHAPES.map((sh, i) => (
        <group key={i} ref={(g) => { items.current[i] = g }} position={[sh.x, sh.y, sh.z]} scale={sh.s}>
          <lineSegments geometry={geos[i]}>
            <lineBasicMaterial color={colors[i % 3]} transparent opacity={palette.additive ? 0.35 : 0.4} depthWrite={false} />
          </lineSegments>
        </group>
      ))}
    </group>
  )
}

/* ---------------- Neon grid horizon in the hero ---------------- */

function GridHorizon({ palette, animate }: { palette: Palette; animate: boolean }) {
  const lines = useRef<THREE.LineSegments>(null!)
  const material = useRef<THREE.LineBasicMaterial>(null!)
  const geometry = useMemo(() => {
    const HALF = 40
    const NEAR = 4 // keep line ends in front of the camera (camera is at z = 10)
    const FAR = -70
    const pos: number[] = []
    const col: number[] = []
    const base = new THREE.Color(palette.grid)
    const accent = new THREE.Color(palette.gridCenter)
    // lines running toward the horizon
    for (let x = -HALF; x <= HALF; x += 1.5) {
      const c = Math.abs(x) < 0.01 ? accent : base
      pos.push(x, 0, NEAR, x, 0, FAR)
      col.push(c.r, c.g, c.b, c.r, c.g, c.b)
    }
    // cross lines (one extra row so the scroll loop is seamless)
    for (let z = NEAR; z >= FAR; z -= 1.5) {
      pos.push(-HALF, 0, z, HALF, 0, z)
      col.push(base.r, base.g, base.b, base.r, base.g, base.b)
    }
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3))
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3))
    return g
  }, [palette])
  useEffect(() => () => geometry.dispose(), [geometry])

  useFrame((state, delta) => {
    const speed = animate ? 1.4 : 0
    lines.current.position.z = (lines.current.position.z + speed * Math.min(delta, 0.05)) % 1.5
    const vh = state.size.height || 1
    const fade = THREE.MathUtils.clamp(1 - window.scrollY / (vh * 0.9), 0, 1)
    material.current.opacity = fade * (palette.additive ? 0.7 : 0.85)
    lines.current.visible = fade > 0.01
  })

  return (
    <group position={[0, -4.2, 0]}>
      <lineSegments ref={lines} geometry={geometry}>
        <lineBasicMaterial ref={material} vertexColors transparent depthWrite={false} />
      </lineSegments>
    </group>
  )
}

/** Re-render on scroll when the frame loop is paused, so the core follows the photo. */
function ScrollInvalidate() {
  const invalidate = useThree((s) => s.invalidate)
  useEffect(() => {
    const on = () => invalidate()
    window.addEventListener('scroll', on, { passive: true })
    window.addEventListener('resize', on)
    return () => {
      window.removeEventListener('scroll', on)
      window.removeEventListener('resize', on)
    }
  }, [invalidate])
  return null
}

function Fallback() {
  return (
    <div className="absolute inset-0">
      <div className="aurora top-[8%] left-1/2 h-[30rem] w-[30rem] -translate-x-1/2 bg-g2" />
      <div className="aurora top-[30%] left-[25%] h-72 w-72 bg-g1" />
      <div className="aurora top-[40%] left-[65%] h-72 w-72 bg-g3" />
    </div>
  )
}

export default function FutureScene({ dark, anchorId = 'hero-avatar' }: { dark: boolean; anchorId?: string }) {
  const webgl = useWebGL()
  const reduced = useReducedMotion()
  const [heroVisible, setHeroVisible] = useState(true)
  const [wide, setWide] = useState(false)

  useEffect(() => {
    const hero = document.getElementById('home')
    const mq = window.matchMedia('(min-width: 768px)')
    const updateWide = () => setWide(mq.matches)
    updateWide()
    mq.addEventListener('change', updateWide)
    let io: IntersectionObserver | undefined
    if (hero && 'IntersectionObserver' in window) {
      io = new IntersectionObserver(([e]) => setHeroVisible(e.isIntersecting))
      io.observe(hero)
    }
    return () => {
      mq.removeEventListener('change', updateWide)
      io?.disconnect()
    }
  }, [])

  const palette = dark ? DARK : LIGHT
  const animate = !reduced

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-0">
      {webgl === false && <Fallback />}
      {webgl && (
        <Canvas
          flat
          camera={{ position: [0, 0, CAMERA_Z], fov: FOV, near: 0.1, far: 120 }}
          dpr={[1, wide ? 1.5 : 2]}
          gl={{ antialias: false, powerPreference: 'high-performance' }}
          frameloop={animate && heroVisible ? 'always' : 'demand'}
          eventSource={typeof document !== 'undefined' ? document.body : undefined}
          eventPrefix="client"
        >
          <color attach="background" args={[palette.bg]} />
          <fog attach="fog" args={[palette.bg, 14, 60]} />
          <StarField palette={palette} animate={animate} />
          <FloatingShapes palette={palette} animate={animate} />
          <GridHorizon palette={palette} animate={animate} />
          <NeuralCore palette={palette} animate={animate} anchorId={anchorId} />
          <ScrollInvalidate />
        </Canvas>
      )}
    </div>
  )
}
