'use client'

import { useEffect, useMemo, useRef } from 'react'
import { useReducedMotion } from 'motion/react'
import { useInView } from '@/hooks/use-in-view'

type Tag = { label: string; tone: 1 | 2 | 3 }

const TONES = { 1: 'var(--g1)', 2: 'var(--g2)', 3: 'var(--g3)' } as const

export default function SkillSphere({ tags }: { tags: Tag[] }) {
  const reduced = useReducedMotion()
  const [wrapRef, inView] = useInView<HTMLDivElement>('0px')
  const items = useRef<(HTMLSpanElement | null)[]>([])
  const speed = useRef({ x: 0.0025, y: 0.004 })
  const angle = useRef({ x: 0, y: 0 })

  // Evenly spread points on a sphere (Fibonacci lattice)
  const points = useMemo(() => {
    const n = tags.length
    const golden = Math.PI * (3 - Math.sqrt(5))
    return tags.map((_, i) => {
      const y = 1 - (i / (n - 1)) * 2
      const r = Math.sqrt(1 - y * y)
      const theta = golden * i
      return { x: Math.cos(theta) * r, y, z: Math.sin(theta) * r }
    })
  }, [tags])

  useEffect(() => {
    const wrap = wrapRef.current
    if (!wrap) return

    const draw = () => {
      const size = Math.min(wrap.clientWidth, 560)
      const radius = size * 0.4
      const ax = angle.current.x
      const ay = angle.current.y
      const cx = Math.cos(ax)
      const sx = Math.sin(ax)
      const cy = Math.cos(ay)
      const sy = Math.sin(ay)
      points.forEach((p, i) => {
        const el = items.current[i]
        if (!el) return
        // rotate around Y, then X
        const x1 = p.x * cy + p.z * sy
        const z1 = -p.x * sy + p.z * cy
        const y2 = p.y * cx - z1 * sx
        const z2 = p.y * sx + z1 * cx
        const depth = (z2 + 1) / 2 // 0 = back, 1 = front
        const scale = 0.62 + depth * 0.58
        el.style.transform = `translate(-50%, -50%) translate3d(${(x1 * radius).toFixed(1)}px, ${(y2 * radius).toFixed(1)}px, 0) scale(${scale.toFixed(3)})`
        el.style.opacity = (0.22 + depth * 0.78).toFixed(3)
        el.style.zIndex = String(Math.round(depth * 100))
        el.style.filter = depth < 0.35 ? 'blur(1px)' : 'none'
      })
    }

    draw()
    if (reduced || !inView) return

    let frame = 0
    const tick = () => {
      angle.current.x += speed.current.x
      angle.current.y += speed.current.y
      draw()
      frame = requestAnimationFrame(tick)
    }
    frame = requestAnimationFrame(tick)

    const onMove = (e: PointerEvent) => {
      const rect = wrap.getBoundingClientRect()
      const dx = (e.clientX - rect.left) / rect.width - 0.5
      const dy = (e.clientY - rect.top) / rect.height - 0.5
      speed.current = { x: -dy * 0.02, y: dx * 0.02 }
    }
    const onLeave = () => {
      speed.current = { x: 0.0025, y: 0.004 }
    }
    const onResize = () => draw()
    wrap.addEventListener('pointermove', onMove)
    wrap.addEventListener('pointerleave', onLeave)
    window.addEventListener('resize', onResize)
    return () => {
      cancelAnimationFrame(frame)
      wrap.removeEventListener('pointermove', onMove)
      wrap.removeEventListener('pointerleave', onLeave)
      window.removeEventListener('resize', onResize)
    }
  }, [points, reduced, inView, wrapRef])

  return (
    <div
      ref={wrapRef}
      aria-hidden="true"
      className="relative mx-auto aspect-square w-full max-w-[560px] select-none"
    >
      <div className="absolute inset-[12%] rounded-full bg-[radial-gradient(circle,var(--glow),transparent_68%)]" />
      {tags.map((tag, i) => (
        <span
          key={tag.label}
          ref={(el) => {
            items.current[i] = el
          }}
          className="absolute top-1/2 left-1/2 rounded-full px-2 py-0.5 text-sm font-semibold whitespace-nowrap will-change-transform sm:text-base"
          style={{ color: TONES[tag.tone] }}
        >
          {tag.label}
        </span>
      ))}
    </div>
  )
}
