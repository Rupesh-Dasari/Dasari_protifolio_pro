'use client'

import FutureScene from '@/components/3d/future-scene'
import CursorGlow from '@/components/cursor-glow'
import CustomCursor from '@/components/custom-cursor'
import { useIsDark } from '@/components/use-is-dark'

/** The fixed 3D background behind the whole page, plus the cursor light. */
export default function SceneLayer() {
  const dark = useIsDark()
  return (
    <>
      <FutureScene dark={dark} />
      <CursorGlow />
      <CustomCursor />
    </>
  )
}
