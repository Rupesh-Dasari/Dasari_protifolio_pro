'use client'

import { useEffect, useRef, useState } from 'react'
import { useReducedMotion } from 'motion/react'
import { cn } from '@/lib/utils'

const INTERACTIVE = 'a, button, [role="button"], summary, label, select, [data-cursor]'
const TEXT_FIELD = 'input, textarea, [contenteditable="true"]'

/**
 * A glowing dot that follows the mouse exactly, with a gradient ring that trails behind it.
 * The ring grows over links and buttons, shows a label where an element sets data-cursor,
 * and pulses on click. Only used with a real mouse; touch screens keep normal behaviour.
 */
export default function CustomCursor() {
  const reduced = useReducedMotion()
  const [enabled, setEnabled] = useState(false)
  const [mode, setMode] = useState<{ hover: boolean; label: string | null; text: boolean }>({ hover: false, label: null, text: false })
  const [down, setDown] = useState(false)
  const [visible, setVisible] = useState(false)
  const dot = useRef<HTMLDivElement>(null)
  const ring = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const mq = window.matchMedia('(hover: hover) and (pointer: fine)')
    const update = () => setEnabled(mq.matches && !reduced)
    update()
    mq.addEventListener('change', update)
    return () => mq.removeEventListener('change', update)
  }, [reduced])

  useEffect(() => {
    if (!enabled) return
    const root = document.documentElement
    root.classList.add('has-custom-cursor')
    let mx = -100
    let my = -100
    let rx = -100
    let ry = -100
    let frame = 0
    let last = { hover: false, label: null as string | null, text: false }

    const loop = () => {
      rx += (mx - rx) * 0.2
      ry += (my - ry) * 0.2
      if (ring.current) ring.current.style.transform = `translate3d(${rx}px, ${ry}px, 0) translate(-50%, -50%)`
      frame = requestAnimationFrame(loop)
    }
    frame = requestAnimationFrame(loop)

    const onMove = (e: PointerEvent) => {
      if (e.pointerType !== 'mouse') return
      mx = e.clientX
      my = e.clientY
      if (dot.current) dot.current.style.transform = `translate3d(${mx}px, ${my}px, 0) translate(-50%, -50%)`
      setVisible(true)
      const target = e.target instanceof Element ? e.target : null
      const labelEl = target?.closest<HTMLElement>('[data-cursor]')
      const next = {
        hover: !!target?.closest(INTERACTIVE),
        label: labelEl?.dataset.cursor ?? null,
        text: !!target?.closest(TEXT_FIELD),
      }
      if (next.hover !== last.hover || next.label !== last.label || next.text !== last.text) {
        last = next
        setMode(next)
      }
    }
    const onDown = () => setDown(true)
    const onUp = () => setDown(false)
    const onLeave = () => setVisible(false)

    window.addEventListener('pointermove', onMove, { passive: true })
    window.addEventListener('pointerdown', onDown)
    window.addEventListener('pointerup', onUp)
    document.addEventListener('pointerleave', onLeave)
    return () => {
      root.classList.remove('has-custom-cursor')
      cancelAnimationFrame(frame)
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerdown', onDown)
      window.removeEventListener('pointerup', onUp)
      document.removeEventListener('pointerleave', onLeave)
    }
  }, [enabled])

  if (!enabled) return null
  return (
    <>
      <div
        ref={ring}
        aria-hidden="true"
        className={cn(
          'cursor-ring',
          mode.hover && 'is-hover',
          mode.label && 'has-label',
          down && 'is-down',
          (!visible || mode.text) && 'is-hidden',
        )}
      >
        <span className="cursor-label">{mode.label}</span>
      </div>
      <div ref={dot} aria-hidden="true" className={cn('cursor-dot', (!visible || mode.text || mode.label) && 'is-hidden', down && 'is-down')} />
    </>
  )
}
