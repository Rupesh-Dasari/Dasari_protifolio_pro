// All the text on the site lives here. Edit this file to update your portfolio.
import type { StaticImageData } from 'next/image'
import portrait from '@/assets/rupesh.jpg'
import b2iCover from '@/assets/projects/b2i-intelligence-agent.jpg'
import brainCover from '@/assets/projects/brain-tumor-detection.jpg'
import cafeCover from '@/assets/projects/cafe-management.jpg'

export const PROFILE = {
  name: 'Dasari Rupesh',
  shortName: 'Rupesh',
  role: 'Python Developer & AI Automation Engineer',
  location: 'Bengaluru, Karnataka, India',
  email: 'dasarirupesh37@gmail.com',
  phone: '+91 93925 98422',
  phoneLink: 'tel:+919392598422',
  linkedin: 'https://www.linkedin.com/in/dasari-rupesh-62560a2b8',
  github: 'https://github.com/Rupesh-Dasari',
  resume: '/Dasari_Rupesh_Resume.pdf',
  photo: portrait as StaticImageData,
  summary:
    'Python Developer and AI & Automation Engineer building backend services, REST APIs, AI agents and data automation pipelines with Django, FastAPI, LangGraph and MySQL.',
}

// Phrases the hero types out one after another: "I build …"
export const TYPED_PHRASES = [
  'Python backends',
  'AI agents with LangGraph',
  'REST APIs',
  'document automation pipelines',
]

export const ABOUT = [
  'I’m a Python Developer and AI & Automation Engineer at SFJBS Pvt. Ltd. in Bengaluru. I work across Django, Flask and FastAPI backends, and I build AI-enabled features with LLM APIs, AI agents and LangGraph that take manual workflows off people’s hands.',
  'My favourite kind of problem is messy data that needs to become clean, trusted records: scraping, OCR, validation, confidence scoring and safe database writes with rollback.',
  'I graduated in Computer Science & Engineering from Viswam Engineering College with a 9.1 CGPA.',
]

export const QUICK_FACTS = [
  { value: '9.1', label: 'CGPA, B.Tech CSE' },
  { value: 'Elite', label: 'NPTEL grade' },
  { value: '1 year', label: 'Python & AI engineering' },
]

export const NOW = {
  title: 'Python Developer & AI Automation Engineer',
  company: 'SFJBS Pvt. Ltd., Bengaluru',
  building: 'B2I Intelligence Agent',
  stack: ['Django', 'FastAPI', 'Flask', 'LangGraph', 'LLM APIs', 'MySQL', 'AWS S3'],
}

export const CERTIFICATIONS = [
  { name: 'Data Analysis & Decision-Making III', detail: 'NPTEL, Elite grade' },
  { name: 'Python Full Stack Development', detail: 'Saraj Innotech and Qspiders' },
  { name: 'Python Bootcamp', detail: 'Certificate of completion' },
  { name: 'AI, ML & IoT Workshop', detail: 'HUBTools' },
  { name: 'CSE Association', detail: 'Coordinated coding contests; hackathons and problem-solving workshops' },
]

export type TimelineItem = {
  id: string
  kind: 'work' | 'education'
  dates: string
  title: string
  place: string
  summary: string
  details: string[]
  tags: string[]
}

export const TIMELINE: TimelineItem[] = [
  {
    id: 'sfjbs',
    kind: 'work',
    dates: 'Dec 2025 – Present',
    title: 'Python Developer & AI Automation Engineer',
    place: 'SFJBS Pvt. Ltd., Bengaluru',
    summary: 'Backend features and AI-enabled automation for real business workflows.',
    details: [
      'Develop and maintain Python backend features using Django, Flask and FastAPI.',
      'Engineer AI-enabled features by integrating LLM APIs, AI agents and LangGraph with prompt engineering, automating manual workflows.',
      'Design and integrate REST APIs and SQL-backed services; debug, test and optimise code with Git and GitHub.',
    ],
    tags: ['Django', 'FastAPI', 'Flask', 'LangGraph', 'LLM APIs', 'MySQL'],
  },
  {
    id: 'qspiders',
    kind: 'work',
    dates: 'Aug 2025 – Dec 2025',
    title: 'Python Full Stack Development Trainee',
    place: 'Qspiders',
    summary: 'Four months of full-stack training.',
    details: [
      'Completed 4-month training in Python, SQL, HTML, CSS and JavaScript.',
      'Built web apps with MySQL and CRUD operations.',
    ],
    tags: ['Python', 'SQL', 'JavaScript', 'HTML', 'CSS', 'MySQL'],
  },
  {
    id: 'btech',
    kind: 'education',
    dates: 'Nov 2022 – May 2026',
    title: 'B.Tech in Computer Science & Engineering',
    place: 'Viswam Engineering College, Madanapalle',
    summary: 'Graduated with a 9.1 CGPA.',
    details: [
      'CGPA 9.1.',
      'NPTEL Data Analysis & Decision-Making III with an Elite grade.',
      'Coordinated coding contests for the CSE Association.',
    ],
    tags: ['CGPA 9.1'],
  },
  {
    id: 'inter',
    kind: 'education',
    dates: 'Jul 2020 – Aug 2022',
    title: 'Intermediate (MPC)',
    place: 'S.V. Junior College, Dharmavaram',
    summary: 'Mathematics, Physics and Chemistry.',
    details: ['CGPA 8.3.'],
    tags: ['CGPA 8.3'],
  },
  {
    id: 'ssc',
    kind: 'education',
    dates: 'Jun 2019 – May 2020',
    title: 'Secondary School Certificate',
    place: 'Z.P. High School, Kanumukkala',
    summary: 'School final.',
    details: ['CGPA 9.8.'],
    tags: ['CGPA 9.8'],
  },
]

export type Project = {
  id: string
  name: string
  tagline: string
  context: string
  description: string
  points: string[]
  stack: string[]
  image: StaticImageData
  imageAlt: string
  link?: string // GitHub repository
  demo?: string // live, deployed app
  color: string // planet colour in the 3D galaxy
}

export const PROJECTS: Project[] = [
  {
    id: 'b2i',
    name: 'B2I Intelligence Agent',
    tagline: 'Document intelligence pipeline',
    context: 'Built at SFJBS Pvt. Ltd.',
    description:
      'An end-to-end app that finds the right contact person (SPOC) in college PDF reports and loads their name, designation, email and phone into MySQL.',
    points: [
      'Automated downloader scrapes college websites, uploads reports to AWS S3 and saves links to the database.',
      'OCR for scanned pages, High / Medium / Low confidence scoring and automatic duplicate detection.',
      'Human-in-the-loop review with validation, audit logging, a batch-import CLI with dry-run, and transactional pushes with rollback.',
    ],
    stack: ['Python', 'MySQL', 'AWS S3', 'OCR', 'Web Scraping'],
    image: b2iCover,
    imageAlt:
      'B2I Intelligence Agent dashboard: a table of contacts extracted from college PDF reports with confidence and status, and a review panel to approve or reject a contact',
    demo: 'https://ai-agent-b2-i-rupesh-2vl057zkx-sfj-platform.vercel.app/',
    color: '#38bdf8',
  },
  {
    id: 'brain',
    name: 'Brain Tumor Detection System',
    tagline: 'Deep learning on MRI scans',
    context: 'Personal project',
    description:
      'A deep learning image classification model that detects brain tumors from MRI scans.',
    points: [
      'OpenCV preprocessing of MRI images to improve accuracy.',
      'Image classifier built with TensorFlow, evaluated with Scikit-learn.',
    ],
    stack: ['Python', 'TensorFlow', 'OpenCV', 'Scikit-learn'],
    image: brainCover,
    imageAlt:
      'Brain Tumor Detection app: an MRI scan with the tumor region boxed, the OpenCV preprocessing steps, and the model prediction',
    link: 'https://github.com/Rupesh-Dasari',
    color: '#e879f9',
  },
  {
    id: 'cafe',
    name: 'Café Management System',
    tagline: 'Full-stack web app',
    context: 'Personal project',
    description:
      'A full-stack web app for running a café, from taking orders to printing the bill.',
    points: [
      'Real-time order tracking and menu management.',
      'Billing with role-based dashboards for admins and customers.',
    ],
    stack: ['Python', 'MySQL', 'HTML', 'CSS'],
    image: cafeCover,
    imageAlt: 'Café Admin dashboard: live orders in New, Preparing and Ready columns, and the bill for one order',
    link: 'https://github.com/Rupesh-Dasari',
    color: '#a5b4fc',
  },
]

export const SKILL_GROUPS = [
  { name: 'Programming', icon: 'code', items: ['Python', 'SQL', 'JavaScript', 'OOP', 'Data Structures'] },
  { name: 'Backend & APIs', icon: 'server', items: ['Django', 'FastAPI', 'Flask', 'REST APIs', 'API Integration', 'JSON', 'CRUD'] },
  { name: 'AI & GenAI', icon: 'sparkles', items: ['LLM Integration', 'AI Agents', 'LangGraph', 'Prompt Engineering', 'Workflow Automation'] },
  { name: 'Data & Automation', icon: 'workflow', items: ['PDF Data Extraction', 'OCR', 'Web Scraping', 'Data Validation', 'ETL Pipelines', 'Pandas', 'NumPy'] },
  { name: 'Databases & Cloud', icon: 'database', items: ['MySQL', 'Database Design', 'Transactions', 'AWS S3'] },
  { name: 'Machine Learning', icon: 'brain', items: ['Scikit-learn', 'TensorFlow', 'OpenCV', 'Image Processing'] },
  { name: 'Frontend & Tools', icon: 'wrench', items: ['React', 'HTML5', 'CSS3', 'Git', 'GitHub', 'Postman', 'VS Code'] },
] as const

export const NAV_ITEMS = [
  { name: 'About', href: '#about' },
  { name: 'Journey', href: '#journey' },
  { name: 'Projects', href: '#projects' },
  { name: 'Skills', href: '#skills' },
  { name: 'Contact', href: '#contact' },
]
