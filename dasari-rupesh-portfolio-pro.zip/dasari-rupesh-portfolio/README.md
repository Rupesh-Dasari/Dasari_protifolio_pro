# Dasari Rupesh — Portfolio

A futuristic, interactive developer portfolio built with **Next.js 16**, **React 19**, **Three.js** (via React Three Fiber), **Tailwind CSS v4** and **Motion**.

The design is inspired by [modern-portfolio](https://github.com/senotron/modern-portfolio) by senotron (MIT License).

## What's inside

- **Intro**: a short "boot sequence" when the page opens (click to skip).
- **3D background (WebGL)**: softly twinkling stars, floating wireframe crystals that drift past at a different depth as you scroll, and a neon grid horizon in the hero.
- **Hero**: photo with a clean gradient ring and a faint 3D network halo, typing effect, magnetic buttons.
- **Featured projects**: a 3D carousel of professional app screenshots with a glossy reflection. Drag, swipe, use the arrows or keyboard, or hover a project button to bring it forward; click the front project to view it full size. Live demo and GitHub buttons.
- **Custom cursor**: a glowing dot with a trailing gradient ring that grows over buttons, shows labels like "View" and "Next" on the carousel, and pulses on click (mouse only; touch screens are unchanged).
- **Hover effects**: glowing card borders that follow the mouse, 3D tilt cards with light glare, lifting chips.
- **About, Journey, Skills, Contact**: tilt cards, an expandable timeline with a light beam, a rotating 3D skill sphere, and a form that opens the visitor's email app.
- Light and dark themes (dark by default), mobile friendly, and it respects "reduce motion" settings.

## Run it on your computer

You need Node.js 20.9 or newer.

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Edit your content

All text is in **`lib/data.ts`**: profile, typed phrases, about, timeline, projects, skills and certifications.

- Photo: replace `assets/rupesh.jpg` (a 3:4 portrait works best).
- Project images: replace the files in `assets/projects/` (16:9, for example 1600×900). The included images are designed mockups with sample data; real screenshots of your apps are even better.
- Project links: set `demo` (live app) and `link` (GitHub) on each project in `lib/data.ts`.
- Resume: replace `public/Dasari_Rupesh_Resume.pdf`.
- Colours: the theme tokens are at the top of `app/globals.css`.

## Put it online (free) with Vercel

1. Push this folder to a new GitHub repository.
2. Go to https://vercel.com, sign in with GitHub, click **Add New → Project**, and pick the repo.
3. Click **Deploy**. Vercel detects Next.js automatically.
